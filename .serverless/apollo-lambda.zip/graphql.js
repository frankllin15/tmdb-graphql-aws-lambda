const { ApolloServer, gql } = require('apollo-server-lambda');
const { graphql } = require('graphql')
const { ApolloServerPluginLandingPageGraphQLPlayground } = require('apollo-server-core')
const typeDefs  = require('./schemas')
const resolvers = require('./resolvers')

const server = new ApolloServer({
  typeDefs,
  resolvers,
  introspection: true,
  plugins: [
    ApolloServerPluginLandingPageGraphQLPlayground()
  ]
})

exports.graphqlHandler = server.createHandler();
